1. Buka cmd dan install composer
2. Buka XAMPP, nyalakan apache dan sql, klik admin pada sql dan masukan laravel_toko_online.sql ke dalam database
3. buka cmd dan jalankan php artisan serve
4. copy ip yang muncul