<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Produk;
use Illuminate\Support\Facades\DB;
class ProdukController extends Controller
{
    public function index()
    {
        //menampilkan data produk yang dijoin dengan table kategori
        //kemudian dikasih paginasi 9 data per halaman nya
        $kat = DB::table('kategori')
                ->join('produk','produk.categories_id','=','kategori.id')
                ->select(DB::raw('count(produk.categories_id) as jumlah, kategori.*'))
                ->groupBy('kategori.id')
                ->get();
        $data = array(
            'produks' => DB::table('produk')->paginate(9),
            'categories' => $kat
        );
        return view('user.produk',$data);
    }
    public function detail($id)
    {
        //mengambil detail produk
        $data = array(
            'produk' => DB::table('produk')->where('id', '=', $id)->first()
        );
        return view('user.produkdetail',$data);
    }

    public function cari(Request $request)
    {
        //mencari produk yang dicari user
        $prod  = Produk::where('name','like','%' . $request->cari. '%')->paginate(9);
        $total = Produk::where('name','like','%' . $request->cari. '%')->count(); 
        $data  = array(
            'produks' => $prod,
            'cari' => $request->cari,
            'total' => $total
        );
        return view('user.cariproduk',$data);

    }
}
