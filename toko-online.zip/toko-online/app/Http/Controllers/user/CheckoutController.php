<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class CheckoutController extends Controller
{
    public function index()
    {
        //ambil session user id
        $id_user = Auth::user()->id;
        //ambil produk apa saja yang akan dibeli user dari table keranjang
        $keranjangs = DB::table('keranjang')
                            ->join('users','users.id','=','keranjang.user_id')
                            ->join('produk','produk.id','=','keranjang.products_id')
                            ->select('produk.name as nama_produk','produk.image','produk.weigth','users.name','keranjang.*','produk.price')
                            ->where('keranjang.user_id','=',$id_user)
                            ->get();
        //lalu hitung jumlah berat total dari semua produk yang akan di beli
        $berattotal = 0;
        foreach($keranjangs as $k){
            $berat = $k->weigth * $k->qty;
            $berattotal = $berattotal + $berat;
        }
       
        //lalu ambil alamat user untuk ditampilkan di view
        $alamat_user = DB::table('alamat')
        ->join('kota','kota.city_id','=','alamat.cities_id')
        ->join('provinsi','provinsi.province_id','=','kota.province_id')
        ->select('alamat.*','kota.title as kota','provinsi.title as prov')
        ->where('alamat.user_id',$id_user)
        ->first();    
        //buat kode invoice sesua tanggalbulantahun dan jam
        $data = [
            'invoice' => 'ALV'.Date('Ymdhi'),
            'keranjangs' => $keranjangs,
            'alamat' => $alamat_user
        ];
        return view('user.checkout',$data);
    }
}
