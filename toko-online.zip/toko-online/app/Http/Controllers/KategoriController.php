<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Kategori;
use App\Produk;
use Illuminate\Support\Facades\DB;
class KategoriController extends Controller
{
    public function produkByKategori($id)
    {
       //menampilkan data sesua kategori yang diminta user
        $data = array(
            'produks' => Produk::where('categories_id',$id)->paginate(9),
            'categories' => Kategori::findOrFail($id)
        );
        return view('user.kategori',$data);
    }
}
