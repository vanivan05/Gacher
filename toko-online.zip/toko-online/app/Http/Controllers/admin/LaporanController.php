<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class LaporanController extends Controller
{
    public function index()
    {
       //ambil data order yang status nya 1 atau masih baru/belum melalukan pembayaran
        $order = DB::table('order')
                    ->join('status_order','status_order.id','=','order.status_order_id')
                    ->join('users','users.id','=','order.user_id')
                    ->select('order.*','status_order.name','users.name as nama_pemesan')
                    ->where('order.status_order_id',1)
                    ->get();
        $data = array(
            'orderbaru' => $order
        );

        return view('admin.laporan.index',$data);
    }
    
    public function filter(Request $request)
    {
    	
    	$bulan = $request->bulan;
    	$tahun = $request->tahun;
    	//dd($bulan);
         //ambil data order yang status nya 1 atau masih baru/belum melalukan pembayaran
        $order = DB::table('order')
                    ->join('status_order','status_order.id','=','order.status_order_id')
                    ->join('users','users.id','=','order.user_id')
                    ->select('order.*','status_order.name','users.name as nama_pemesan')
                    ->whereYear('order.created_at', '=', $tahun)
                    ->whereMonth('order.created_at', '=', $bulan)
                    ->get();
        $data = array(
            'orderbaru' => $order,
            'bulan' => $bulan,
            'tahun' => $tahun,
            
        );

        return view('admin.laporan.filter',$data);
    }
}
